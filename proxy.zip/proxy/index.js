const express = require("express");
const noderfc = require("node-rfc");
const session = require("express-session");
const bodyParser = require("body-parser");
const xml2js = require("xml2js");

var stateful_clients = [];
const STATEFUL_POOL_SIZE = 10;
let stateful_index = 0;

const app = express();
const port = 1080;

app.use(
  bodyParser.urlencoded({
    extended: true,
    limit: "100mb",
    verify: (req, res, buf) => {
      req.rawBody = buf;
    },
  })
);

app.use(
  bodyParser.text({
    type: "*/*",
    limit: "100mb",
    verify: (req, res, buf) => {
      req.rawBody = buf;
    },
  })
);

app.use(
  session({
    secret: "secretSTATEFUL",
    resave: true,
    saveUninitialized: true,
    cookie: { secure: false },
  })
);

const username = "KAAR-3090";
const password = "KTern@2019";
const sysnr = "00";
const client_number = "210";
const ashost = "172.17.19.18";

function transformUsageReferenceRequest(url, body) {
  if (
    url.includes("/sap/bc/adt/repository/informationsystem/usageReferences")
  ) {
    console.log("UsageReference request detected, transforming body...");
    console.log("Original URL:", url);
    console.log("Original body:", body);

    const properXmlBody = `<?xml version="1.0" encoding="ASCII"?>
<usagereferences:usageReferenceRequest xmlns:usagereferences="http://www.sap.com/adt/ris/usageReferences">
  <usagereferences:affectedObjects/>
</usagereferences:usageReferenceRequest>`;

    console.log("Transformed XML body:", properXmlBody);
    return properXmlBody;
  }

  if (url.includes("/sap/bc/adt/repository/informationsystem/usageSnippets")) {
    console.log("UsageSnippets request detected, transforming body...");
    console.log("Original URL:", url);
    console.log("Original body:", body);

    const properXmlBody = `<?xml version="1.0" encoding="UTF-8"?>
<usagereferences:usageSnippetRequest xmlns:usagereferences="http://www.sap.com/adt/ris/usageReferences">
  <usagereferences:objectIdentifiers>
  </usagereferences:objectIdentifiers>
  <usagereferences:affectedObjects/>
</usagereferences:usageSnippetRequest>`;

    console.log("Transformed XML body for snippets:", properXmlBody);
    return properXmlBody;
  }

  return body;
}

function request_rfc(method, req, res) {
  (async () => {
    try {
      var clnt;
      var stfl = false;

      for (const key in req.headers) {
        if (req.headers[key].includes("stateful")) {
          stfl = true;
        }
      }

      if (stfl === true) {
        clnt = stateful_clients[stateful_index];
        stateful_index = (stateful_index + 1) % STATEFUL_POOL_SIZE;
        console.log(`Using stateful client ${stateful_index} for ${req.url}`);
      } else {
        clnt = new noderfc.Client({
          stateful: false,
          user: username,
          passwd: password,
          sysnr: sysnr,
          client: client_number,
          ashost: ashost,
        });
        await clnt.open();
        console.log(`Created new stateless client for ${req.url}`);
      }

      console.log(req.url);
      if (req.url.includes("ZUTU")) {
        console.log("ZUTU request detected");
      }

      const request_line = {
        METHOD: method,
        URI: req.url,
        VERSION: "HTTP/1.1",
      };
      let headers = [];

      for (const key in req.headers) {
        headers.push({ NAME: key, VALUE: req.headers[key] });
      }

      var sadt_request;

      const originalBody = req.rawBody ? req.rawBody.toString("utf8") : "";
      const transformedBody = transformUsageReferenceRequest(
        req.url,
        originalBody
      );
      if (
        req.body &&
        Object.keys(req.body).length < 1 &&
        transformedBody === originalBody
      ) {
        sadt_request = {
          REQUEST_LINE: request_line,
          HEADER_FIELDS: headers,
          MESSAGE_BODY: new Buffer(2),
        };
      } else {
        sadt_request = {
          REQUEST_LINE: request_line,
          HEADER_FIELDS: headers,
          MESSAGE_BODY: new Buffer(transformedBody),
        };
      }

      console.log("SADT Request: ", sadt_request);
      const result = await clnt.call("SADT_REST_RFC_ENDPOINT", {
        REQUEST: sadt_request,
      });

      console.log(
        "++++++++++++++_____________+++++++++++++++++++++++++++",
        result
      );
      res.statusCode = result.RESPONSE.STATUS_LINE.STATUS_CODE;

      result.RESPONSE.HEADER_FIELDS.forEach((header) => {
        res.set(header.NAME, header.VALUE);
      });

      const body = result.RESPONSE.MESSAGE_BODY.toString();
      // console.log("body structure======", body)
      if (stfl === false) {
        await clnt.close();
      }

      res.send(body);
    } catch (err) {
      console.error(err);
      res.send(err);
    }
  })();
}

(async () => {
  try {
    console.log("Initializing SAP stateful connection pool...");

    for (let i = 0; i < STATEFUL_POOL_SIZE; i++) {
      const rfc_client = new noderfc.Client({
        stateful: true,
        user: username,
        passwd: password,
        sysnr: sysnr,
        client: client_number,
        ashost: ashost,
      });
      await rfc_client.open();
      stateful_clients.push(rfc_client);
      console.log(`Stateful client ${i + 1}/${STATEFUL_POOL_SIZE} connected`);
    }

    console.log("SAP stateful connection pool established successfully");

    app.get("/*", (req, res) => {
      request_rfc("GET", req, res);
    });

    app.post("/*", (req, res) => {
      request_rfc("POST", req, res);
    });

    app.put("/*", (req, res) => {
      request_rfc("PUT", req, res);
    });

    app.listen(port, () => {
      console.log(`Connector Listening on Port ${port}`);
    });
  } catch (connectionError) {
    console.error("Failed to establish SAP connection:", connectionError);
    process.exit(1);
  }
})();

process.on("SIGINT", async () => {
  console.log("Closing SAP stateful connections...");

  for (let i = 0; i < stateful_clients.length; i++) {
    try {
      await stateful_clients[i].close();
      console.log(`Closed stateful client ${i + 1}`);
    } catch (err) {
      console.error(`Error closing stateful client ${i + 1}:`, err);
    }
  }

  process.exit(0);
});
