const express = require("express");
const noderfc = require("node-rfc");
const prompt = require("prompt");
const session = require("express-session");
const bodyParser = require("body-parser");

var stateful_client;

const app = express();
const port = 1080;

app.use(
  bodyParser.urlencoded({
    extended: true,
    limit: "100mb",
    verify: (req, res, buf) => {
      req.rawBody = buf;
    },
  })
);

app.use(
  bodyParser.text({
    type: "*/*",
    limit: "100mb",
    verify: (req, res, buf) => {
      req.rawBody = buf;
    },
  })
);

app.use(
  session({
    secret: "secretSTATEFUL",
    resave: true,
    saveUninitialized: true,
    cookie: { secure: false },
  })
);

const username = "KAAR-3090";
const password = "KTern@2019";
const sysnr = "00";
const client_number = "210";
const ashost = "http://172.17.19.18";


function onErr(err) {
  console.log(err);
  return 1;
}

function request_rfc(method, req, res) {
  (async () => {
    try {
      var clnt;
      var stfl = false;

      for (const key in req.headers) {
        if (req.headers[key].includes("stateful")) {
          stfl = true;
        }
      }

      if (stfl === true) {
        clnt = stateful_client;
      } else {
        clnt = new noderfc.Client({
          stateful: false,
          user: username,
          passwd: password,
          sysnr: sysnr,
          client: client_number,
          ashost: ashost,
        });
        await clnt.open();
      }

      const request_line = {
        METHOD: method,
        URI: req.url,
        VERSION: "HTTP/1.1",
      };
      let headers = [];

      for (const key in req.headers) {
        headers.push({ NAME: key, VALUE: req.headers[key] });
      }

      var sadt_request;
      console.log(req)
      if (!req.body || Object.keys(req.body).length < 1) {
        sadt_request = {
          REQUEST_LINE: request_line,
          HEADER_FIELDS: headers,
          MESSAGE_BODY: Buffer.alloc(2), // use Buffer.alloc instead of deprecated new Buffer
        };
      } else {
        sadt_request = {
          REQUEST_LINE: request_line,
          HEADER_FIELDS: headers,
          MESSAGE_BODY: Buffer.from(req.rawBody.toString("utf8")),
        };
      }
      console.log(
        "asc++++++++++++++++++++++++++++++++++++++++++++++++++",
        sadt_request
      );
      const result = await clnt.call("SADT_REST_RFC_ENDPOINT", {
        REQUEST: sadt_request,
      });

      console.log(
        "RESULT++++++++++++++++++++++++++++++++++++++++++++++++++",
        result
      );

      res.statusCode = result.RESPONSE.STATUS_LINE.STATUS_CODE;

      result.RESPONSE.HEADER_FIELDS.forEach((header) => {
        res.set(header.NAME, header.VALUE);
      });

      const body = result.RESPONSE.MESSAGE_BODY.toString();

      res.send(body);
    } catch (err) {
      console.error(err);
    }
  })();
}

stateful_client = new noderfc.Client({
  stateful: true,
  user: username,
  passwd: password,
  sysnr: sysnr,
  client: client_number,
  ashost: ashost,
});
stateful_client.open();

app.get("/*", (req, res) => {
  request_rfc("GET", req, res);
});

app.post("/*", (req, res) => {
  request_rfc("POST", req, res);
});

app.put("/*", (req, res) => {
  request_rfc("PUT", req, res);
});

app.listen(port, () => {
  console.log(`Connector Listening on Port ${port}`);
});
